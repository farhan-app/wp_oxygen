<?php
/*
Plugin Name:    Tocbot
Plugin URI: https://farhan.app/
Description:   Tocbot plugin created for Oxygen Builder.
Version:    1.0.0
Author:		Farhan
Author URI:	https://farhan.app/
*/

// prevent public user to directly access .php file through URL

add_action( 'wp_enqueue_scripts', 'custom_enqueue_files' );
function custom_enqueue_files() {


	//tocbot
	if ( is_singular( 'post' ) ) {

		wp_enqueue_script(
			'tocbot',
			plugin_dir_url( __FILE__ ) . 'assets/tocbot.min.js',
			array(),
			'4.3.1',
			true
		);

	} // End if()
}

/**
 * Automatically add IDs to headings such as <h2></h2>
 */
function auto_id_headings( $content ) {

	$content = preg_replace_callback( '/(\<h[1-6](.*?))\>(.*)(<\/h[1-6]>)/i', function( $matches ) {
		if ( ! stripos( $matches[0], 'id=' ) ) :
			$matches[0] = $matches[1] . $matches[2] . ' id="' . sanitize_title( $matches[3] ) . '">' . $matches[3] . $matches[4];
		endif;
		return $matches[0];
	}, $content );

    return $content;

}
add_filter( 'the_content', 'auto_id_headings' );
?>