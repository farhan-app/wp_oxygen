<?php
/*
Plugin Name:    My.code
Plugin URI: https://farhan.app/
Description:    My.code plugin created by <a href="https://farhan.app/">Farhan</a> for Oxygen Builder.
Version:    1.0.0
Author:		Farhan
*/

if ( ! defined( 'WPINC' ) ) {
	die;
}

add_action( 'wp_enqueue_scripts', 'my_code' );

function my_code() {

	wp_enqueue_style( 'my-css', plugin_dir_url( __FILE__ ) . 'assets/css/style.css' );

	wp_enqueue_script( 'my-js', plugin_dir_url( __FILE__ ) . 'assets/js/scripts.js', '', '2.0.8', true );

}

?>